import React, { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'user' | 'phlebo' | 'admin';

export interface User {
  id: string;
  role: UserRole;
  name: string;
  phone?: string;
  isBlocked?: boolean;
}

interface AuthContextType {
  user: User | null;
  login: (credentials: LoginCredentials) => boolean;
  logout: () => void;
  isAuthenticated: boolean;
}

interface LoginCredentials {
  role: UserRole;
  phone?: string;
  id?: string;
  password?: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ADMIN_CREDENTIALS = { id: '6003045851', password: '06102003' };
const INITIAL_PHLEBO_CREDENTIALS = { id: '6003045851', password: '10122003' };

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    const stored = localStorage.getItem('smartlab_user');
    return stored ? JSON.parse(stored) : null;
  });

  const login = (credentials: LoginCredentials): boolean => {
    let newUser: User | null = null;

    switch (credentials.role) {
      case 'user':
        if (credentials.phone && credentials.phone.length === 10) {
          newUser = {
            id: credentials.phone,
            role: 'user',
            name: `User ${credentials.phone}`,
            phone: credentials.phone,
          };
        }
        break;

      case 'admin':
        if (credentials.id === ADMIN_CREDENTIALS.id && credentials.password === ADMIN_CREDENTIALS.password) {
          newUser = {
            id: credentials.id,
            role: 'admin',
            name: 'Admin',
          };
        }
        break;

      case 'phlebo':
        const phlebos = JSON.parse(localStorage.getItem('smartlab_phlebos') || '[]');
        const phlebo = phlebos.find((p: any) => p.id === credentials.id && p.password === credentials.password);
        
        if (phlebo || (credentials.id === INITIAL_PHLEBO_CREDENTIALS.id && credentials.password === INITIAL_PHLEBO_CREDENTIALS.password)) {
          const phlebotomist = phlebo || {
            id: INITIAL_PHLEBO_CREDENTIALS.id,
            name: 'Initial Phlebo',
            password: INITIAL_PHLEBO_CREDENTIALS.password,
            isBlocked: false,
            totalCommission: 0,
            cashCollected: 0,
          };

          if (!phlebotomist.isBlocked) {
            newUser = {
              id: phlebotomist.id,
              role: 'phlebo',
              name: phlebotomist.name,
            };
          }
        }
        break;
    }

    if (newUser) {
      setUser(newUser);
      localStorage.setItem('smartlab_user', JSON.stringify(newUser));
      return true;
    }

    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('smartlab_user');
  };

  return (
    <AuthContext.Provider value={{
      user,
      login,
      logout,
      isAuthenticated: !!user,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}