import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import * as Animatable from 'react-native-animatable';
import LinearGradient from 'react-native-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useData } from '../context/DataContext';

export default function MyBookingsScreen({ navigation }) {
  const { bookings } = useData();

  const getStatusColor = (status) => {
    switch (status) {
      case 'confirmed': return '#4ecdc4';
      case 'assigned': return '#feca57';
      case 'collected': return '#ff9ff3';
      case 'processing': return '#45b7d1';
      case 'ready': return '#96ceb4';
      default: return '#667eea';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'confirmed': return 'checkmark-circle';
      case 'assigned': return 'person';
      case 'collected': return 'flask';
      case 'processing': return 'cog';
      case 'ready': return 'document-text';
      default: return 'time';
    }
  };

  return (
    <LinearGradient colors={['#667eea', '#764ba2']} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        {/* Header */}
        <Animatable.View animation="fadeInDown" style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <Ionicons name="arrow-back" size={24} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>My Bookings</Text>
          <View style={styles.placeholder} />
        </Animatable.View>

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {bookings.length === 0 ? (
            <Animatable.View animation="fadeInUp" style={styles.emptyContainer}>
              <Ionicons name="calendar-outline" size={80} color="rgba(255,255,255,0.5)" />
              <Text style={styles.emptyTitle}>No Bookings Yet</Text>
              <Text style={styles.emptySubtitle}>
                Your test bookings will appear here
              </Text>
              <TouchableOpacity
                style={styles.bookNowButton}
                onPress={() => navigation.navigate('BookTest')}
              >
                <Text style={styles.bookNowText}>Book Your First Test</Text>
              </TouchableOpacity>
            </Animatable.View>
          ) : (
            bookings.map((booking, index) => (
              <Animatable.View
                key={booking.id}
                animation="fadeInUp"
                delay={index * 100}
                style={styles.bookingCard}
              >
                <View style={styles.bookingHeader}>
                  <View style={styles.bookingInfo}>
                    <Text style={styles.bookingId}>#{booking.id}</Text>
                    <Text style={styles.bookingDate}>
                      {new Date(booking.createdAt).toLocaleDateString()}
                    </Text>
                  </View>
                  <View style={[
                    styles.statusBadge,
                    { backgroundColor: getStatusColor(booking.status) }
                  ]}>
                    <Ionicons 
                      name={getStatusIcon(booking.status)} 
                      size={16} 
                      color="#fff" 
                    />
                    <Text style={styles.statusText}>
                      {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                    </Text>
                  </View>
                </View>

                <View style={styles.bookingDetails}>
                  <View style={styles.labInfo}>
                    <Ionicons name="business" size={16} color="rgba(255,255,255,0.8)" />
                    <Text style={styles.labText}>{booking.lab}</Text>
                  </View>
                  
                  <View style={styles.testsContainer}>
                    <Text style={styles.testsTitle}>Tests:</Text>
                    {booking.tests.map((test, testIndex) => (
                      <Text key={testIndex} style={styles.testName}>
                        • {test.name}
                      </Text>
                    ))}
                  </View>

                  <View style={styles.amountContainer}>
                    <Text style={styles.amountLabel}>Total Amount:</Text>
                    <Text style={styles.amountValue}>₹{booking.totalAmount}</Text>
                  </View>

                  {booking.isUrgent && (
                    <View style={styles.urgentBadge}>
                      <Ionicons name="flash" size={14} color="#ff6b6b" />
                      <Text style={styles.urgentText}>URGENT</Text>
                    </View>
                  )}
                </View>

                {/* Progress Bar */}
                <View style={styles.progressContainer}>
                  <View style={styles.progressBar}>
                    <View 
                      style={[
                        styles.progressFill,
                        { 
                          width: booking.status === 'confirmed' ? '20%' :
                                booking.status === 'assigned' ? '40%' :
                                booking.status === 'collected' ? '60%' :
                                booking.status === 'processing' ? '80%' : '100%',
                          backgroundColor: getStatusColor(booking.status)
                        }
                      ]} 
                    />
                  </View>
                  <View style={styles.progressSteps}>
                    <Text style={styles.progressStep}>Confirmed</Text>
                    <Text style={styles.progressStep}>Assigned</Text>
                    <Text style={styles.progressStep}>Collected</Text>
                    <Text style={styles.progressStep}>Processing</Text>
                    <Text style={styles.progressStep}>Ready</Text>
                  </View>
                </View>
              </Animatable.View>
            ))
          )}
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  backButton: {
    padding: 5,
  },
  headerTitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 34,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 100,
  },
  emptyTitle: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
  },
  emptySubtitle: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 30,
  },
  bookNowButton: {
    backgroundColor: '#4ecdc4',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 25,
  },
  bookNowText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  bookingCard: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
  },
  bookingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  bookingInfo: {
    flex: 1,
  },
  bookingId: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  bookingDate: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    marginTop: 2,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 15,
  },
  statusText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 5,
  },
  bookingDetails: {
    marginBottom: 20,
  },
  labInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  labText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    marginLeft: 8,
  },
  testsContainer: {
    marginBottom: 15,
  },
  testsTitle: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  testName: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    marginBottom: 4,
  },
  amountContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  amountLabel: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
  },
  amountValue: {
    color: '#4ecdc4',
    fontSize: 18,
    fontWeight: 'bold',
  },
  urgentBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255, 107, 107, 0.2)',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#ff6b6b',
  },
  urgentText: {
    color: '#ff6b6b',
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 5,
  },
  progressContainer: {
    marginTop: 10,
  },
  progressBar: {
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.3)',
    borderRadius: 2,
    marginBottom: 10,
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  progressSteps: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  progressStep: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 10,
    flex: 1,
    textAlign: 'center',
  },
});