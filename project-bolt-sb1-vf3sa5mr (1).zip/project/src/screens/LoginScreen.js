import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import * as Animatable from 'react-native-animatable';
import LinearGradient from 'react-native-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';

export default function LoginScreen({ navigation }) {
  const [role, setRole] = useState('user');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [adminId, setAdminId] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();

  const handleLogin = async () => {
    setLoading(true);
    
    try {
      let credentials = { role };
      
      if (role === 'user') {
        if (!phone || phone.length !== 10) {
          Alert.alert('Error', 'Please enter a valid 10-digit phone number');
          setLoading(false);
          return;
        }
        credentials.phone = phone;
      } else if (role === 'admin') {
        if (!adminId || !password) {
          Alert.alert('Error', 'Please enter admin ID and password');
          setLoading(false);
          return;
        }
        if ((adminId !== '6003045851' && adminId !== '8822633164') || password !== '06102003') {
          Alert.alert('Error', 'Invalid admin credentials');
          setLoading(false);
          return;
        }
        credentials.adminId = adminId;
        credentials.password = password;
      } else if (role === 'phlebo') {
        if (!adminId || !password) {
          Alert.alert('Error', 'Please enter phlebo ID and password');
          setLoading(false);
          return;
        }
        credentials.phlebId = adminId;
        credentials.password = password;
      }

      const success = await login(credentials);
      
      if (success) {
        // Navigate based on role
        switch (role) {
          case 'user':
            navigation.replace('UserDashboard');
            break;
          case 'phlebo':
            navigation.replace('PhleboDashboard');
            break;
          case 'admin':
            navigation.replace('AdminDashboard');
            break;
        }
      } else {
        Alert.alert('Error', 'Login failed. Please check your credentials.');
      }
    } catch (error) {
      Alert.alert('Error', 'Something went wrong. Please try again.');
    }
    
    setLoading(false);
  };

  const roleButtons = [
    { key: 'user', label: 'User', icon: 'person', color: '#4ecdc4' },
    { key: 'phlebo', label: 'Phlebo', icon: 'medical', color: '#45b7d1' },
    { key: 'admin', label: 'Admin', icon: 'settings', color: '#f093fb' },
  ];

  return (
    <LinearGradient colors={['#667eea', '#764ba2']} style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView contentContainerStyle={styles.scrollContent}>
          {/* Header */}
          <Animatable.View animation="fadeInDown" style={styles.header}>
            <View style={styles.logoContainer}>
              <Ionicons name="medical" size={50} color="#fff" />
            </View>
            <Text style={styles.title}>Welcome Back</Text>
            <Text style={styles.subtitle}>Sign in to continue</Text>
          </Animatable.View>

          {/* Role Selection */}
          <Animatable.View animation="fadeInUp" delay={300} style={styles.roleContainer}>
            <Text style={styles.roleTitle}>Select Role</Text>
            <View style={styles.roleButtons}>
              {roleButtons.map((roleBtn) => (
                <TouchableOpacity
                  key={roleBtn.key}
                  style={[
                    styles.roleButton,
                    { backgroundColor: role === roleBtn.key ? roleBtn.color : 'rgba(255,255,255,0.2)' }
                  ]}
                  onPress={() => setRole(roleBtn.key)}
                >
                  <Ionicons 
                    name={roleBtn.icon} 
                    size={24} 
                    color={role === roleBtn.key ? '#fff' : 'rgba(255,255,255,0.7)'} 
                  />
                  <Text style={[
                    styles.roleButtonText,
                    { color: role === roleBtn.key ? '#fff' : 'rgba(255,255,255,0.7)' }
                  ]}>
                    {roleBtn.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </Animatable.View>

          {/* Login Form */}
          <Animatable.View animation="fadeInUp" delay={600} style={styles.formContainer}>
            {role === 'user' ? (
              <View style={styles.inputContainer}>
                <Ionicons name="call" size={20} color="#fff" style={styles.inputIcon} />
                <TextInput
                  style={styles.input}
                  placeholder="Enter 10-digit mobile number"
                  placeholderTextColor="rgba(255,255,255,0.7)"
                  value={phone}
                  onChangeText={setPhone}
                  keyboardType="phone-pad"
                  maxLength={10}
                />
              </View>
            ) : (
              <>
                <View style={styles.inputContainer}>
                  <Ionicons name="person" size={20} color="#fff" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder={`Enter ${role} ID`}
                    placeholderTextColor="rgba(255,255,255,0.7)"
                    value={adminId}
                    onChangeText={setAdminId}
                  />
                </View>
                <View style={styles.inputContainer}>
                  <Ionicons name="lock-closed" size={20} color="#fff" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="Enter password"
                    placeholderTextColor="rgba(255,255,255,0.7)"
                    value={password}
                    onChangeText={setPassword}
                    secureTextEntry
                  />
                </View>
              </>
            )}

            <TouchableOpacity
              style={styles.loginButton}
              onPress={handleLogin}
              disabled={loading}
            >
              <Text style={styles.loginButtonText}>
                {loading ? 'Signing In...' : 'Sign In'}
              </Text>
              <Ionicons name="arrow-forward" size={20} color="#667eea" />
            </TouchableOpacity>
          </Animatable.View>

          {/* Footer */}
          {role === 'user' && (
            <Animatable.View animation="fadeInUp" delay={900} style={styles.footer}>
              <Text style={styles.footerText}>Don't have an account?</Text>
              <TouchableOpacity onPress={() => navigation.navigate('Signup')}>
                <Text style={styles.signupText}>Sign Up</Text>
              </TouchableOpacity>
            </Animatable.View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: 30,
    paddingVertical: 50,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logoContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.8)',
  },
  roleContainer: {
    marginBottom: 30,
  },
  roleTitle: {
    fontSize: 18,
    color: '#fff',
    marginBottom: 15,
    textAlign: 'center',
    fontWeight: '600',
  },
  roleButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  roleButton: {
    flex: 1,
    paddingVertical: 15,
    paddingHorizontal: 10,
    borderRadius: 15,
    alignItems: 'center',
    marginHorizontal: 5,
  },
  roleButtonText: {
    fontSize: 12,
    fontWeight: '600',
    marginTop: 5,
  },
  formContainer: {
    marginBottom: 30,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 15,
    marginBottom: 20,
    paddingHorizontal: 20,
  },
  inputIcon: {
    marginRight: 15,
  },
  input: {
    flex: 1,
    paddingVertical: 18,
    fontSize: 16,
    color: '#fff',
  },
  loginButton: {
    backgroundColor: '#fff',
    paddingVertical: 18,
    borderRadius: 15,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  loginButtonText: {
    color: '#667eea',
    fontSize: 18,
    fontWeight: 'bold',
    marginRight: 10,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  footerText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 16,
  },
  signupText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 5,
  },
});