import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAuthState();
  }, []);

  const checkAuthState = async () => {
    try {
      const userData = await AsyncStorage.getItem('user');
      if (userData) {
        setUser(JSON.parse(userData));
      }
    } catch (error) {
      console.error('Error checking auth state:', error);
    } finally {
      setLoading(false);
    }
  };

  const login = async (credentials) => {
    try {
      let userData = null;

      if (credentials.role === 'user') {
        // For demo purposes, create user with phone number
        userData = {
          id: credentials.phone,
          name: `User ${credentials.phone}`,
          phone: credentials.phone,
          role: 'user',
        };
      } else if (credentials.role === 'admin') {
        // Admin login with fixed credentials
        if (
          (credentials.adminId === '6003045851' || credentials.adminId === '8822633164') &&
          credentials.password === '06102003'
        ) {
          userData = {
            id: credentials.adminId,
            name: 'Admin',
            role: 'admin',
          };
        }
      } else if (credentials.role === 'phlebo') {
        // For demo purposes, allow any phlebo login
        userData = {
          id: credentials.phlebId,
          name: `Phlebo ${credentials.phlebId}`,
          role: 'phlebo',
        };
      }

      if (userData) {
        await AsyncStorage.setItem('user', JSON.stringify(userData));
        setUser(userData);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const logout = async () => {
    try {
      await AsyncStorage.removeItem('user');
      setUser(null);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const value = {
    user,
    login,
    logout,
    loading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};