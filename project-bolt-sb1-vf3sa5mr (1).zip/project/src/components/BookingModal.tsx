import React, { useState } from 'react';
import { X, Search, Plus, Minus, Upload, CreditCard } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';

interface BookingModalProps {
  onClose: () => void;
}

export default function BookingModal({ onClose }: BookingModalProps) {
  const { user } = useAuth();
  const { tests, addBooking } = useData();
  const [selectedLab, setSelectedLab] = useState('Lal Path');
  const [selectedTests, setSelectedTests] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [paymentPercentage, setPaymentPercentage] = useState(100);
  const [prescription, setPrescription] = useState<File | null>(null);

  const labs = ['Lal Path', 'Lupin', 'Biomed', 'Metropolis'];
  
  const filteredTests = tests.filter(test =>
    test.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const calculatePrice = (test: any) => {
    const discount = test.discounts[selectedLab as keyof typeof test.discounts] || 0;
    return Math.round(test.mrp * (1 - discount / 100));
  };

  const totalAmount = selectedTests.reduce((sum, testId) => {
    const test = tests.find(t => t.id === testId);
    return sum + (test ? calculatePrice(test) : 0);
  }, 0);

  const advanceAmount = Math.round((totalAmount * paymentPercentage) / 100);

  const handleTestToggle = (testId: string) => {
    setSelectedTests(prev =>
      prev.includes(testId)
        ? prev.filter(id => id !== testId)
        : [...prev, testId]
    );
  };

  const handleBooking = () => {
    if (selectedTests.length === 0 || !user) return;

    const testNames = selectedTests.map(testId => {
      const test = tests.find(t => t.id === testId);
      return test?.name || '';
    }).filter(Boolean);

    addBooking({
      userId: user.id,
      userName: user.name,
      userPhone: user.phone || '',
      tests: testNames,
      lab: selectedLab,
      totalAmount,
      paidAmount: advanceAmount,
      status: 'confirmed',
      prescription: prescription?.name,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-6 flex items-center justify-between">
          <h2 className="text-2xl font-bold">Book Lab Tests</h2>
          <button onClick={onClose} className="p-2 hover:bg-white/20 rounded-lg">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          {/* Lab Selection */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-3">Select Lab</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {labs.map(lab => (
                <button
                  key={lab}
                  onClick={() => setSelectedLab(lab)}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    selectedLab === lab
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  {lab}
                </button>
              ))}
            </div>
          </div>

          {/* Test Search */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search for tests..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Test Selection */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-3">Select Tests</h3>
            <div className="max-h-60 overflow-y-auto border border-gray-200 rounded-lg">
              {filteredTests.map(test => {
                const price = calculatePrice(test);
                const isSelected = selectedTests.includes(test.id);
                
                return (
                  <div
                    key={test.id}
                    className={`p-4 border-b border-gray-100 last:border-b-0 cursor-pointer transition-colors ${
                      isSelected ? 'bg-blue-50' : 'hover:bg-gray-50'
                    }`}
                    onClick={() => handleTestToggle(test.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{test.name}</h4>
                        <div className="flex items-center space-x-4 mt-1">
                          <span className="text-sm text-gray-500 line-through">₹{test.mrp}</span>
                          <span className="text-lg font-bold text-green-600">₹{price}</span>
                          <span className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded">
                            {test.discounts[selectedLab as keyof typeof test.discounts]}% OFF
                          </span>
                        </div>
                      </div>
                      <button
                        className={`p-2 rounded-full transition-colors ${
                          isSelected
                            ? 'bg-blue-500 text-white'
                            : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                        }`}
                      >
                        {isSelected ? <Minus className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Prescription Upload */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-3">Upload Prescription (Optional)</h3>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
              <input
                type="file"
                accept="image/*,.pdf"
                onChange={(e) => setPrescription(e.target.files?.[0] || null)}
                className="hidden"
                id="prescription"
              />
              <label htmlFor="prescription" className="cursor-pointer">
                <span className="text-blue-600 hover:text-blue-800">Click to upload</span>
                <span className="text-gray-600"> or drag and drop</span>
              </label>
              {prescription && (
                <p className="mt-2 text-sm text-green-600">
                  Uploaded: {prescription.name}
                </p>
              )}
            </div>
          </div>

          {/* Payment Options */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-3">Payment Options</h3>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <span>Pay in Advance:</span>
                <span className="font-bold">{paymentPercentage}%</span>
              </div>
              <input
                type="range"
                min="25"
                max="100"
                step="25"
                value={paymentPercentage}
                onChange={(e) => setPaymentPercentage(Number(e.target.value))}
                className="w-full mb-3"
              />
              <div className="grid grid-cols-4 gap-2 text-xs text-center">
                <div>25%</div>
                <div>50%</div>
                <div>75%</div>
                <div>100%</div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-gray-50 p-6 border-t">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm text-gray-600">
                Selected: {selectedTests.length} tests
              </p>
              <div className="flex items-center space-x-4">
                <p className="text-lg font-bold">Total: ₹{totalAmount}</p>
                <p className="text-green-600 font-medium">Pay Now: ₹{advanceAmount}</p>
                {paymentPercentage < 100 && (
                  <p className="text-orange-600 font-medium">
                    Balance: ₹{totalAmount - advanceAmount}
                  </p>
                )}
              </div>
            </div>
            <div className="flex space-x-3">
              <button
                onClick={onClose}
                className="px-6 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleBooking}
                disabled={selectedTests.length === 0}
                className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-lg hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
              >
                <CreditCard className="h-4 w-4" />
                <span>Book & Pay</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}