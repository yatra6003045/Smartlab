import React from 'react';
import { Calendar, MapPin, Clock, CreditCard, FileText, X } from 'lucide-react';
import { useData, Booking } from '../contexts/DataContext';
import { useAuth } from '../contexts/AuthContext';

interface BookingListProps {
  bookings: Booking[];
}

export default function BookingList({ bookings }: BookingListProps) {
  const { updateBooking } = useData();
  const { user } = useAuth();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-blue-100 text-blue-800';
      case 'assigned': return 'bg-yellow-100 text-yellow-800';
      case 'collected': return 'bg-purple-100 text-purple-800';
      case 'in_lab': return 'bg-orange-100 text-orange-800';
      case 'report_ready': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getProgressWidth = (status: string) => {
    switch (status) {
      case 'confirmed': return '20%';
      case 'assigned': return '40%';
      case 'collected': return '60%';
      case 'in_lab': return '80%';
      case 'report_ready': return '100%';
      default: return '0%';
    }
  };

  const handleCancelBooking = (booking: Booking) => {
    if (booking.status === 'confirmed' || booking.status === 'assigned') {
      updateBooking(booking.id, { status: 'confirmed' }); // Or implement proper cancellation
    }
  };

  return (
    <div className="space-y-6">
      {bookings.map(booking => (
        <div key={booking.id} className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">
                Booking #{booking.id}
              </h3>
              <div className="flex items-center space-x-4 mt-1 text-sm text-gray-600">
                <div className="flex items-center space-x-1">
                  <Calendar className="h-4 w-4" />
                  <span>{new Date(booking.createdAt).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <MapPin className="h-4 w-4" />
                  <span>{booking.lab}</span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <span className={`px-3 py-1 rounded-full text-sm font-medium capitalize ${getStatusColor(booking.status)}`}>
                {booking.status.replace('_', ' ')}
              </span>
              {booking.isUrgent && (
                <div className="bg-red-100 text-red-800 px-2 py-1 rounded text-xs mt-1">
                  URGENT
                </div>
              )}
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mb-4">
            <div className="flex justify-between text-xs text-gray-600 mb-1">
              <span>Confirmed</span>
              <span>Assigned</span>
              <span>Collected</span>
              <span>In Lab</span>
              <span>Report Ready</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-500"
                style={{ width: getProgressWidth(booking.status) }}
              ></div>
            </div>
          </div>

          {/* Tests */}
          <div className="mb-4">
            <h4 className="font-medium text-gray-900 mb-2">Tests:</h4>
            <div className="flex flex-wrap gap-2">
              {booking.tests.map((test, index) => (
                <span key={index} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                  {test}
                </span>
              ))}
            </div>
          </div>

          {/* Payment Info */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2 text-sm">
                <CreditCard className="h-4 w-4 text-gray-500" />
                <span className="text-gray-600">Total: ₹{booking.totalAmount}</span>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <span className="text-green-600">Paid: ₹{booking.paidAmount}</span>
              </div>
              {booking.paidAmount < booking.totalAmount && (
                <div className="flex items-center space-x-2 text-sm">
                  <span className="text-orange-600">
                    Balance: ₹{booking.totalAmount - booking.paidAmount}
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center space-x-2">
              {/* Cancel Button (only if not collected) */}
              {user?.role === 'user' && (booking.status === 'confirmed' || booking.status === 'assigned') && (
                <button
                  onClick={() => handleCancelBooking(booking)}
                  className="text-red-600 hover:text-red-800 p-2 hover:bg-red-50 rounded-lg transition-colors"
                  title="Cancel Booking"
                >
                  <X className="h-4 w-4" />
                </button>
              )}

              {/* Report Button */}
              {booking.status === 'report_ready' && booking.paidAmount >= booking.totalAmount && (
                <button className="bg-gradient-to-r from-green-500 to-green-600 text-white px-4 py-2 rounded-lg hover:shadow-lg transition-all duration-300 flex items-center space-x-2">
                  <FileText className="h-4 w-4" />
                  <span>View Report</span>
                </button>
              )}

              {/* Locked Report */}
              {booking.status === 'report_ready' && booking.paidAmount < booking.totalAmount && (
                <div className="bg-amber-100 text-amber-800 px-4 py-2 rounded-lg text-sm flex items-center space-x-2">
                  <Clock className="h-4 w-4" />
                  <span>Complete payment to unlock report</span>
                </div>
              )}
            </div>
          </div>

          {/* Assigned Phlebo */}
          {booking.assignedPhlebo && (
            <div className="bg-gray-50 rounded-lg p-3">
              <p className="text-sm text-gray-600">
                Assigned to: <span className="font-medium">{booking.assignedPhlebo}</span>
              </p>
            </div>
          )}
        </div>
      ))}

      {bookings.length === 0 && (
        <div className="text-center py-12">
          <Calendar className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <p className="text-white text-lg">No bookings found</p>
          <p className="text-white/70">Your booking history will appear here</p>
        </div>
      )}
    </div>
  );
}