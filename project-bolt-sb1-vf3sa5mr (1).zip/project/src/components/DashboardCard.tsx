import React, { ReactNode } from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface DashboardCardProps {
  title: string;
  value?: string | number;
  icon: LucideIcon;
  color: string;
  onClick?: () => void;
  children?: ReactNode;
  className?: string;
}

export default function DashboardCard({ 
  title, 
  value, 
  icon: Icon, 
  color, 
  onClick, 
  children,
  className = ''
}: DashboardCardProps) {
  return (
    <div
      className={`bg-white/90 backdrop-blur-sm rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 cursor-pointer ${className}`}
      onClick={onClick}
    >
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className={`p-3 rounded-lg bg-gradient-to-r ${color}`}>
            <Icon className="h-6 w-6 text-white" />
          </div>
          {value && (
            <div className="text-right">
              <p className="text-2xl font-bold text-gray-900">{value}</p>
            </div>
          )}
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">{title}</h3>
        {children}
      </div>
    </div>
  );
}