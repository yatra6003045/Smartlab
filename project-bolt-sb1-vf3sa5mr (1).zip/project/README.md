# SMARTLAB SILCHAR - Android App

A comprehensive diagnostic and pathology service mobile application built with React Native and Expo.

## Features

### 🎨 **Beautiful UI/UX**
- Rainbow gradient themes throughout the app
- Smooth animations and transitions
- Professional loading screens
- Responsive design for all screen sizes

### 🔐 **Authentication System**
- Role-based login (User/Phlebo/Admin)
- Phone number authentication for users
- Secure admin credentials
- Persistent login sessions

### 🧪 **Comprehensive Test Booking**
- 200+ medical tests with accurate pricing
- Multiple lab options with different discounts:
  - Lal PathLabs: 10% discount
  - Lupin: 15% discount
  - Biomed: 15% discount
  - Metropolis: 25% discount
- Urgent booking option
- Real-time price calculation

### 📱 **User Dashboard Features**
- **Book a Test**: Browse and select from comprehensive test catalog
- **My Bookings**: Track all test bookings with status updates
- **Download Report**: Access completed reports (payment-gated)
- **Payment Status**: View payment history and pending amounts
- **AI Chatbot**: Multi-language health assistant (English/Hindi/Bengali)
- **Offers & Discounts**: View current promotions

### 📊 **Booking Status Tracking**
Complete workflow tracking:
1. **Booking Confirmed** → 2. **Phlebo Assigned** → 3. **Sample Collected** → 4. **In Lab** → 5. **Processing** → 6. **Report Ready**

### 🤖 **AI Health Assistant**
- Multi-language support (English, Hindi, Bengali)
- Medical and sexual health guidance
- 24/7 availability
- Context-aware responses

### 💳 **Payment Integration**
- QR code payment scanning
- Payment screenshot upload
- Partial payment support
- Payment-gated report access

### 🔧 **Technical Features**
- Firebase backend integration
- Offline data persistence
- Push notifications ready
- Camera and file system access
- Secure data storage

## Installation & Setup

### Prerequisites
- Node.js (v16 or higher)
- Expo CLI
- Android Studio (for Android development)
- Xcode (for iOS development - macOS only)

### Quick Start

1. **Clone and Install**
```bash
git clone <repository-url>
cd smartlab-silchar-app
npm install
```

2. **Start Development Server**
```bash
npm start
# or
expo start
```

3. **Run on Device/Emulator**
```bash
# Android
npm run android
# or scan QR code with Expo Go app

# iOS (macOS only)
npm run ios
```

### Building APK

```bash
# Build Android APK
expo build:android

# Build iOS (requires Apple Developer account)
expo build:ios
```

## Firebase Configuration

Replace the demo Firebase config in `App.js` with your actual Firebase project credentials:

```javascript
const firebaseConfig = {
  apiKey: "your-api-key",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "your-sender-id",
  appId: "your-app-id"
};
```

## Admin Credentials

**Admin Login:**
- ID: `6003045851` or `8822633164`
- Password: `06102003`

## Project Structure

```
src/
├── screens/           # All app screens
├── context/          # React Context for state management
├── components/       # Reusable UI components
└── utils/           # Helper functions

assets/              # Images, icons, splash screens
```

## Key Screens

- **WelcomeScreen**: Animated onboarding
- **LoginScreen**: Role-based authentication
- **UserDashboard**: Main user interface with grid layout
- **BookTestScreen**: Test selection and booking
- **MyBookingsScreen**: Booking history and tracking
- **ChatbotScreen**: AI health assistant
- **PaymentScreen**: Payment management
- **ReportScreen**: Report download and viewing

## Deployment

### Android Play Store
1. Build signed APK: `expo build:android`
2. Upload to Google Play Console
3. Complete store listing and publish

### iOS App Store
1. Build IPA: `expo build:ios`
2. Upload to App Store Connect
3. Complete app review process

### Web Deployment
```bash
expo build:web
# Deploy to Netlify, Vercel, or Firebase Hosting
```

## Features Roadmap

- [ ] Push notifications for booking updates
- [ ] Offline mode support
- [ ] Biometric authentication
- [ ] Telemedicine integration
- [ ] Health record management
- [ ] Family member profiles
- [ ] Insurance integration
- [ ] Prescription upload and analysis

## Support

For technical support or feature requests, please contact the development team.

## License

© 2024 SMARTLAB SILCHAR. All rights reserved.