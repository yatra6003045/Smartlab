import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import Header from '../components/Header';
import DashboardCard from '../components/DashboardCard';
import Chatbot from '../components/Chatbot';
import BookingModal from '../components/BookingModal';
import BookingList from '../components/BookingList';
import { 
  Calendar, 
  FileText, 
  Download, 
  Clock, 
  CreditCard,
  TestTube,
  Activity
} from 'lucide-react';

export default function UserDashboard() {
  const { user } = useAuth();
  const { bookings } = useData();
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [activeView, setActiveView] = useState<'dashboard' | 'bookings' | 'reports'>('dashboard');

  const userBookings = bookings.filter(booking => booking.userId === user?.id);
  const pendingReports = userBookings.filter(booking => booking.status === 'report_ready' && booking.paidAmount >= booking.totalAmount);
  const unpaidBookings = userBookings.filter(booking => booking.paidAmount < booking.totalAmount);

  if (activeView === 'bookings') {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white">My Bookings</h2>
            <button
              onClick={() => setActiveView('dashboard')}
              className="bg-white/20 text-white px-4 py-2 rounded-lg hover:bg-white/30 transition-colors"
            >
              Back to Dashboard
            </button>
          </div>
          <BookingList bookings={userBookings} />
        </div>
        <Chatbot />
      </div>
    );
  }

  if (activeView === 'reports') {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white">My Reports</h2>
            <button
              onClick={() => setActiveView('dashboard')}
              className="bg-white/20 text-white px-4 py-2 rounded-lg hover:bg-white/30 transition-colors"
            >
              Back to Dashboard
            </button>
          </div>
          <div className="grid gap-6">
            {pendingReports.map(booking => (
              <div key={booking.id} className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-lg">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Booking #{booking.id}</h3>
                    <p className="text-sm text-gray-600">Lab: {booking.lab}</p>
                  </div>
                  <div className="text-right">
                    <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                      Report Ready
                    </span>
                  </div>
                </div>
                <div className="mb-4">
                  <h4 className="font-medium text-gray-900 mb-2">Tests:</h4>
                  <div className="flex flex-wrap gap-2">
                    {booking.tests.map((test, index) => (
                      <span key={index} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
                        {test}
                      </span>
                    ))}
                  </div>
                </div>
                {booking.reportUrl ? (
                  <button className="bg-gradient-to-r from-green-500 to-green-600 text-white px-4 py-2 rounded-lg hover:shadow-lg transition-all duration-300 flex items-center space-x-2">
                    <Download className="h-4 w-4" />
                    <span>Download Report</span>
                  </button>
                ) : (
                  <p className="text-amber-600 text-sm">Report is being processed...</p>
                )}
              </div>
            ))}
            {pendingReports.length === 0 && (
              <div className="text-center py-12">
                <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <p className="text-white text-lg">No reports available</p>
                <p className="text-white/70">Complete your tests to view reports here</p>
              </div>
            )}
          </div>
        </div>
        <Chatbot />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Welcome, {user?.name}!</h2>
          <p className="text-white/80">Book tests, track progress, and access your reports</p>
        </div>

        {/* Dashboard Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <DashboardCard
            title="Book New Test"
            icon={Calendar}
            color="from-blue-500 to-blue-600"
            onClick={() => setShowBookingModal(true)}
          />
          
          <DashboardCard
            title="My Bookings"
            value={userBookings.length}
            icon={TestTube}
            color="from-green-500 to-green-600"
            onClick={() => setActiveView('bookings')}
          />
          
          <DashboardCard
            title="Pending Reports"
            value={pendingReports.length}
            icon={FileText}
            color="from-purple-500 to-purple-600"
            onClick={() => setActiveView('reports')}
          />
          
          <DashboardCard
            title="Pending Payments"
            value={`₹${unpaidBookings.reduce((sum, booking) => sum + (booking.totalAmount - booking.paidAmount), 0)}`}
            icon={CreditCard}
            color="from-orange-500 to-orange-600"
          />
        </div>

        {/* Recent Bookings */}
        <div className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold text-gray-900">Recent Bookings</h3>
            <button
              onClick={() => setActiveView('bookings')}
              className="text-blue-600 hover:text-blue-800 font-medium"
            >
              View All
            </button>
          </div>
          
          {userBookings.slice(0, 3).map(booking => (
            <div key={booking.id} className="flex items-center justify-between py-4 border-b border-gray-200 last:border-b-0">
              <div className="flex items-center space-x-4">
                <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-2 rounded-lg">
                  <Activity className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="font-medium text-gray-900">Booking #{booking.id}</p>
                  <p className="text-sm text-gray-600">{booking.lab} • {booking.tests.length} tests</p>
                </div>
              </div>
              <div className="text-right">
                <span className={`px-3 py-1 rounded-full text-sm font-medium capitalize ${
                  booking.status === 'confirmed' ? 'bg-blue-100 text-blue-800' :
                  booking.status === 'assigned' ? 'bg-yellow-100 text-yellow-800' :
                  booking.status === 'collected' ? 'bg-purple-100 text-purple-800' :
                  booking.status === 'in_lab' ? 'bg-orange-100 text-orange-800' : 
                  'bg-green-100 text-green-800'
                }`}>
                  {booking.status.replace('_', ' ')}
                </span>
                <p className="text-xs text-gray-500 mt-1">₹{booking.totalAmount}</p>
              </div>
            </div>
          ))}
          
          {userBookings.length === 0 && (
            <div className="text-center py-12">
              <Clock className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 text-lg">No bookings yet</p>
              <button
                onClick={() => setShowBookingModal(true)}
                className="mt-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-lg hover:shadow-lg transition-all duration-300"
              >
                Book Your First Test
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Booking Modal */}
      {showBookingModal && (
        <BookingModal onClose={() => setShowBookingModal(false)} />
      )}

      <Chatbot />
    </div>
  );
}