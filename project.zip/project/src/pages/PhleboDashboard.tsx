import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import Header from '../components/Header';
import DashboardCard from '../components/DashboardCard';
import Chatbot from '../components/Chatbot';
import BookingModal from '../components/BookingModal';
import { 
  Calendar, 
  Users, 
  DollarSign, 
  Package, 
  CheckCircle,
  Clock,
  CreditCard,
  QrCode
} from 'lucide-react';

export default function PhleboDashboard() {
  const { user } = useAuth();
  const { bookings, updateBooking, phlebotomists, updatePhlebotomist } = useData();
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [activeView, setActiveView] = useState<'dashboard' | 'assigned' | 'commission'>('dashboard');

  const currentPhlebo = phlebotomists.find(p => p.id === user?.id);
  const assignedBookings = bookings.filter(booking => booking.assignedPhlebo === user?.name);
  const totalCommission = currentPhlebo?.totalCommission || 0;
  const cashCollected = currentPhlebo?.cashCollected || 0;

  const handleStatusUpdate = (bookingId: string, newStatus: string) => {
    updateBooking(bookingId, { status: newStatus as any });
    
    // Update commission when sample is collected
    if (newStatus === 'collected' && currentPhlebo) {
      const booking = bookings.find(b => b.id === bookingId);
      if (booking) {
        const commission = Math.round(booking.totalAmount * 0.1); // 10% commission
        updatePhlebotomist(currentPhlebo.id, {
          totalCommission: currentPhlebo.totalCommission + commission
        });
      }
    }
  };

  const handleCashSubmission = () => {
    if (currentPhlebo && cashCollected > 0) {
      updatePhlebotomist(currentPhlebo.id, {
        cashCollected: 0
      });
      alert('Cash submitted successfully!');
    }
  };

  if (activeView === 'assigned') {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white">Assigned Bookings</h2>
            <button
              onClick={() => setActiveView('dashboard')}
              className="bg-white/20 text-white px-4 py-2 rounded-lg hover:bg-white/30 transition-colors"
            >
              Back to Dashboard
            </button>
          </div>
          
          <div className="space-y-6">
            {assignedBookings.map(booking => (
              <div key={booking.id} className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">
                      Booking #{booking.id}
                    </h3>
                    <p className="text-gray-600">Patient: {booking.userName}</p>
                    <p className="text-gray-600">Phone: {booking.userPhone}</p>
                    <p className="text-gray-600">Lab: {booking.lab}</p>
                  </div>
                  <div className="text-right">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium capitalize ${
                      booking.status === 'assigned' ? 'bg-yellow-100 text-yellow-800' :
                      booking.status === 'collected' ? 'bg-purple-100 text-purple-800' :
                      booking.status === 'in_lab' ? 'bg-orange-100 text-orange-800' : 
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {booking.status.replace('_', ' ')}
                    </span>
                  </div>
                </div>

                <div className="mb-4">
                  <h4 className="font-medium text-gray-900 mb-2">Tests:</h4>
                  <div className="flex flex-wrap gap-2">
                    {booking.tests.map((test, index) => (
                      <span key={index} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
                        {test}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <p className="text-lg font-bold text-gray-900">Amount: ₹{booking.totalAmount}</p>
                  <div className="flex space-x-2">
                    {booking.status === 'assigned' && (
                      <button
                        onClick={() => handleStatusUpdate(booking.id, 'collected')}
                        className="bg-gradient-to-r from-green-500 to-green-600 text-white px-4 py-2 rounded-lg hover:shadow-lg transition-all duration-300 flex items-center space-x-2"
                      >
                        <CheckCircle className="h-4 w-4" />
                        <span>Mark Collected</span>
                      </button>
                    )}
                    {booking.status === 'collected' && (
                      <button
                        onClick={() => handleStatusUpdate(booking.id, 'in_lab')}
                        className="bg-gradient-to-r from-purple-500 to-purple-600 text-white px-4 py-2 rounded-lg hover:shadow-lg transition-all duration-300 flex items-center space-x-2"
                      >
                        <Package className="h-4 w-4" />
                        <span>Hand to Lab</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
            
            {assignedBookings.length === 0 && (
              <div className="text-center py-12">
                <Clock className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <p className="text-white text-lg">No assigned bookings</p>
                <p className="text-white/70">New assignments will appear here</p>
              </div>
            )}
          </div>
        </div>
        <Chatbot />
      </div>
    );
  }

  if (activeView === 'commission') {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white">Commission & Payments</h2>
            <button
              onClick={() => setActiveView('dashboard')}
              className="bg-white/20 text-white px-4 py-2 rounded-lg hover:bg-white/30 transition-colors"
            >
              Back to Dashboard
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-gradient-to-r from-green-500 to-green-600 p-3 rounded-lg">
                  <DollarSign className="h-8 w-8 text-white" />
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold text-gray-900">₹{totalCommission}</p>
                  <p className="text-gray-600">Total Commission</p>
                </div>
              </div>
              <p className="text-sm text-gray-600">10% of test amounts from completed collections</p>
            </div>

            <div className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-gradient-to-r from-orange-500 to-orange-600 p-3 rounded-lg">
                  <CreditCard className="h-8 w-8 text-white" />
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold text-gray-900">₹{cashCollected}</p>
                  <p className="text-gray-600">Cash Collected</p>
                </div>
              </div>
              <button
                onClick={handleCashSubmission}
                disabled={cashCollected === 0}
                className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-2 px-4 rounded-lg hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                <QrCode className="h-4 w-4" />
                <span>Submit Cash to Admin</span>
              </button>
            </div>
          </div>

          <div className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Commission History</h3>
            <div className="space-y-3">
              {assignedBookings.filter(b => b.status !== 'assigned').map(booking => (
                <div key={booking.id} className="flex items-center justify-between py-3 border-b border-gray-200">
                  <div>
                    <p className="font-medium text-gray-900">Booking #{booking.id}</p>
                    <p className="text-sm text-gray-600">{booking.userName} • {booking.lab}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-green-600">+₹{Math.round(booking.totalAmount * 0.1)}</p>
                    <p className="text-xs text-gray-500">Commission</p>
                  </div>
                </div>
              ))}
              {assignedBookings.filter(b => b.status !== 'assigned').length === 0 && (
                <p className="text-gray-500 text-center py-8">No commission history yet</p>
              )}
            </div>
          </div>
        </div>
        <Chatbot />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Welcome, {user?.name}!</h2>
          <p className="text-white/80">Manage your assignments and track your earnings</p>
        </div>

        {/* Dashboard Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <DashboardCard
            title="Assigned Bookings"
            value={assignedBookings.length}
            icon={Calendar}
            color="from-blue-500 to-blue-600"
            onClick={() => setActiveView('assigned')}
          />
          
          <DashboardCard
            title="Self Book Test"
            icon={Users}
            color="from-green-500 to-green-600"
            onClick={() => setShowBookingModal(true)}
          />
          
          <DashboardCard
            title="Total Commission"
            value={`₹${totalCommission}`}
            icon={DollarSign}
            color="from-purple-500 to-purple-600"
            onClick={() => setActiveView('commission')}
          />
          
          <DashboardCard
            title="Cash Collected"
            value={`₹${cashCollected}`}
            icon={CreditCard}
            color="from-orange-500 to-orange-600"
          />
        </div>

        {/* Recent Assignments */}
        <div className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold text-gray-900">Recent Assignments</h3>
            <button
              onClick={() => setActiveView('assigned')}
              className="text-blue-600 hover:text-blue-800 font-medium"
            >
              View All
            </button>
          </div>
          
          {assignedBookings.slice(0, 3).map(booking => (
            <div key={booking.id} className="flex items-center justify-between py-4 border-b border-gray-200 last:border-b-0">
              <div className="flex items-center space-x-4">
                <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-2 rounded-lg">
                  <Users className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="font-medium text-gray-900">{booking.userName}</p>
                  <p className="text-sm text-gray-600">{booking.userPhone} • {booking.tests.length} tests</p>
                </div>
              </div>
              <div className="text-right">
                <span className={`px-3 py-1 rounded-full text-sm font-medium capitalize ${
                  booking.status === 'assigned' ? 'bg-yellow-100 text-yellow-800' :
                  booking.status === 'collected' ? 'bg-purple-100 text-purple-800' :
                  booking.status === 'in_lab' ? 'bg-orange-100 text-orange-800' : 
                  'bg-blue-100 text-blue-800'
                }`}>
                  {booking.status.replace('_', ' ')}
                </span>
                <p className="text-xs text-gray-500 mt-1">₹{booking.totalAmount}</p>
              </div>
            </div>
          ))}
          
          {assignedBookings.length === 0 && (
            <div className="text-center py-12">
              <Clock className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 text-lg">No assignments yet</p>
              <p className="text-gray-500">New assignments will appear here</p>
            </div>
          )}
        </div>
      </div>

      {/* Self Booking Modal */}
      {showBookingModal && (
        <BookingModal onClose={() => setShowBookingModal(false)} />
      )}

      <Chatbot />
    </div>
  );
}