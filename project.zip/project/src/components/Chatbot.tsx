import React, { useState } from 'react';
import { MessageCircle, Send, X, Bot } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

export default function Chatbot() {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: getChatbotWelcomeMessage(user?.role || 'user'),
      isBot: true,
      timestamp: new Date(),
    }
  ]);
  const [inputText, setInputText] = useState('');

  function getChatbotWelcomeMessage(role: string): string {
    switch (role) {
      case 'user':
        return 'Hello! I\'m your medical assistant. I can help you with health queries in English, Hindi, or Bengali. How can I assist you today?';
      case 'phlebo':
        return 'Hi! I\'m your SOP assistant. I can help you with procedures, protocols, and work-related queries. What do you need help with?';
      case 'admin':
        return 'Hey there! I\'m your unrestricted AI assistant. I can help with anything - from work tasks to casual conversations. What\'s on your mind?';
      default:
        return 'Hello! How can I help you today?';
    }
  }

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      isBot: false,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');

    // Simulate bot response
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: getBotResponse(inputText, user?.role || 'user'),
        isBot: true,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, botResponse]);
    }, 1000);
  };

  function getBotResponse(input: string, role: string): string {
    const responses = {
      user: [
        'Based on your symptoms, I recommend consulting with a healthcare professional for proper diagnosis.',
        'For general health maintenance, ensure you stay hydrated, exercise regularly, and get adequate sleep.',
        'If you\'re experiencing persistent symptoms, please book a consultation with a doctor.',
        'Regular health check-ups are important for early detection of health issues.',
      ],
      phlebo: [
        'Always follow proper hand hygiene before and after sample collection.',
        'Ensure proper patient identification using at least two identifiers.',
        'Use appropriate collection tubes for different tests as per SOP.',
        'Maintain cold chain for samples that require refrigeration.',
      ],
      admin: [
        'I can help you with platform management, data analysis, or any other queries you might have.',
        'For urgent bookings, make sure to assign the nearest available phlebotomist.',
        'Regular system backups are important for data security.',
        'Consider implementing user feedback system for service improvement.',
      ],
    };

    const roleResponses = responses[role as keyof typeof responses] || responses.user;
    return roleResponses[Math.floor(Math.random() * roleResponses.length)];
  }

  return (
    <>
      {/* Floating Chat Button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 bg-gradient-to-r from-blue-500 to-purple-600 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-110 z-50"
      >
        <MessageCircle className="h-6 w-6" />
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 w-80 h-96 bg-white rounded-lg shadow-2xl border border-gray-200 flex flex-col z-50">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-4 rounded-t-lg flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Bot className="h-5 w-5" />
              <span className="font-medium">AI Assistant</span>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white hover:text-gray-200"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-xs px-3 py-2 rounded-lg ${
                    message.isBot
                      ? 'bg-gray-100 text-gray-800'
                      : 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                  }`}
                >
                  <p className="text-sm">{message.text}</p>
                  <p className="text-xs opacity-70 mt-1">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Input */}
          <div className="p-4 border-t border-gray-200">
            <div className="flex space-x-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Type your message..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={handleSendMessage}
                className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-2 rounded-lg hover:shadow-lg transition-all duration-300"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}