import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { LogOut, Microscope } from 'lucide-react';

export default function Header() {
  const { user, logout } = useAuth();
  const { qrCode } = useData();

  return (
    <header className="bg-white/95 backdrop-blur-sm shadow-lg border-b border-white/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-2 rounded-lg">
              <Microscope className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                SMARTLAB SILCHAR
              </h1>
              <p className="text-xs text-gray-500 capitalize">{user?.role} Dashboard</p>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="hidden sm:block">
              <img src={qrCode} alt="Payment QR" className="h-12 w-12 rounded-lg border-2 border-gray-200" />
            </div>
            <div className="text-right">
              <p className="text-sm font-medium text-gray-900">{user?.name}</p>
              {user?.phone && <p className="text-xs text-gray-500">{user.phone}</p>}
            </div>
            <button
              onClick={logout}
              className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}