import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import * as Animatable from 'react-native-animatable';
import LinearGradient from 'react-native-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

export default function ChatbotScreen({ navigation }) {
  const [messages, setMessages] = useState([
    {
      id: '1',
      text: 'Hello! I\'m your AI health assistant. I can help you with medical questions in English, Hindi, or Bengali. How can I assist you today?',
      isBot: true,
      timestamp: new Date(),
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('English');
  const scrollViewRef = useRef();

  const languages = ['English', 'Hindi', 'Bengali'];

  const medicalResponses = {
    English: [
      'Based on your symptoms, I recommend consulting with a healthcare professional for proper diagnosis.',
      'For general health maintenance, ensure you stay hydrated, exercise regularly, and get adequate sleep.',
      'If you\'re experiencing persistent symptoms, please book a consultation with a doctor.',
      'Regular health check-ups are important for early detection of health issues.',
      'For sexual health concerns, it\'s important to speak with a qualified healthcare provider.',
      'Maintaining a balanced diet rich in fruits and vegetables can boost your immune system.',
      'If you have concerns about STDs, please get tested at a certified laboratory.',
      'Mental health is as important as physical health. Don\'t hesitate to seek professional help.',
    ],
    Hindi: [
      'आपके लक्षणों के आधार पर, मैं सही निदान के लिए एक स्वास्थ्य पेशेवर से सलाह लेने की सलाह देता हूं।',
      'सामान्य स्वास्थ्य रखरखाव के लिए, सुनिश्चित करें कि आप हाइड्रेटेड रहें, नियमित व्यायाम करें और पर्याप्त नींद लें।',
      'यदि आप लगातार लक्षणों का अनुभव कर रहे हैं, तो कृपया डॉक्टर से सलाह लें।',
      'स्वास्थ्य समस्याओं की जल्दी पहचान के लिए नियमित स्वास्थ्य जांच महत्वपूर्ण है।',
      'यौन स्वास्थ्य की चिंताओं के लिए, एक योग्य स्वास्थ्य प्रदाता से बात करना महत्वपूर्ण है।',
    ],
    Bengali: [
      'আপনার উপসর্গের ভিত্তিতে, আমি সঠিক নির্ণয়ের জন্য একজন স্বাস্থ্যসেবা পেশাদারের সাথে পরামর্শ করার পরামর্শ দিই।',
      'সাধারণ স্বাস্থ্য রক্ষণাবেক্ষণের জন্য, নিশ্চিত করুন যে আপনি হাইড্রেটেড থাকুন, নিয়মিত ব্যায়াম করুন এবং পর্যাপ্ত ঘুম পান।',
      'যদি আপনি ক্রমাগত উপসর্গ অনুভব করেন, তাহলে অনুগ্রহ করে একজন ডাক্তারের সাথে পরামর্শ করুন।',
      'স্বাস্থ্য সমস্যার প্রাথমিক সনাক্তকরণের জন্য নিয়মিত স্বাস্থ্য পরীক্ষা গুরুত্বপূর্ণ।',
      'যৌন স্বাস্থ্যের উদ্বেগের জন্য, একজন যোগ্য স্বাস্থ্যসেবা প্রদানকারীর সাথে কথা বলা গুরুত্বপূর্ণ।',
    ]
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage = {
      id: Date.now().toString(),
      text: inputText,
      isBot: false,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');

    // Simulate bot response
    setTimeout(() => {
      const responses = medicalResponses[selectedLanguage];
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      
      const botMessage = {
        id: (Date.now() + 1).toString(),
        text: randomResponse,
        isBot: true,
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, botMessage]);
    }, 1000);
  };

  useEffect(() => {
    scrollViewRef.current?.scrollToEnd({ animated: true });
  }, [messages]);

  return (
    <LinearGradient colors={['#667eea', '#764ba2']} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        {/* Header */}
        <Animatable.View animation="fadeInDown" style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <Ionicons name="arrow-back" size={24} color="#fff" />
          </TouchableOpacity>
          <View style={styles.headerCenter}>
            <Text style={styles.headerTitle}>AI Health Assistant</Text>
            <View style={styles.onlineIndicator}>
              <View style={styles.onlineDot} />
              <Text style={styles.onlineText}>Online</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.settingsButton}>
            <Ionicons name="settings" size={24} color="#fff" />
          </TouchableOpacity>
        </Animatable.View>

        {/* Language Selection */}
        <Animatable.View animation="fadeInUp" delay={200} style={styles.languageContainer}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {languages.map((lang) => (
              <TouchableOpacity
                key={lang}
                style={[
                  styles.languageButton,
                  selectedLanguage === lang && styles.selectedLanguageButton
                ]}
                onPress={() => setSelectedLanguage(lang)}
              >
                <Text style={[
                  styles.languageText,
                  selectedLanguage === lang && styles.selectedLanguageText
                ]}>
                  {lang}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </Animatable.View>

        {/* Messages */}
        <ScrollView
          ref={scrollViewRef}
          style={styles.messagesContainer}
          contentContainerStyle={styles.messagesContent}
          showsVerticalScrollIndicator={false}
        >
          {messages.map((message, index) => (
            <Animatable.View
              key={message.id}
              animation="fadeInUp"
              delay={index * 100}
              style={[
                styles.messageContainer,
                message.isBot ? styles.botMessageContainer : styles.userMessageContainer
              ]}
            >
              {message.isBot && (
                <View style={styles.botAvatar}>
                  <Ionicons name="medical" size={20} color="#fff" />
                </View>
              )}
              <View style={[
                styles.messageBubble,
                message.isBot ? styles.botMessageBubble : styles.userMessageBubble
              ]}>
                <Text style={[
                  styles.messageText,
                  message.isBot ? styles.botMessageText : styles.userMessageText
                ]}>
                  {message.text}
                </Text>
                <Text style={[
                  styles.messageTime,
                  message.isBot ? styles.botMessageTime : styles.userMessageTime
                ]}>
                  {message.timestamp.toLocaleTimeString([], { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </Text>
              </View>
            </Animatable.View>
          ))}
        </ScrollView>

        {/* Input */}
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.inputContainer}
        >
          <Animatable.View animation="slideInUp" style={styles.inputWrapper}>
            <TextInput
              style={styles.textInput}
              placeholder={`Type your message in ${selectedLanguage}...`}
              placeholderTextColor="rgba(255,255,255,0.7)"
              value={inputText}
              onChangeText={setInputText}
              multiline
              maxLength={500}
            />
            <TouchableOpacity
              style={[
                styles.sendButton,
                inputText.trim() && styles.sendButtonActive
              ]}
              onPress={handleSendMessage}
              disabled={!inputText.trim()}
            >
              <Ionicons 
                name="send" 
                size={20} 
                color={inputText.trim() ? '#fff' : 'rgba(255,255,255,0.5)'} 
              />
            </TouchableOpacity>
          </Animatable.View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  backButton: {
    padding: 5,
  },
  headerCenter: {
    flex: 1,
    alignItems: 'center',
  },
  headerTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  onlineIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 2,
  },
  onlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#4ecdc4',
    marginRight: 5,
  },
  onlineText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 12,
  },
  settingsButton: {
    padding: 5,
  },
  languageContainer: {
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  languageButton: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 10,
  },
  selectedLanguageButton: {
    backgroundColor: '#4ecdc4',
  },
  languageText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    fontWeight: '600',
  },
  selectedLanguageText: {
    color: '#fff',
  },
  messagesContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },
  messagesContent: {
    paddingVertical: 20,
  },
  messageContainer: {
    flexDirection: 'row',
    marginBottom: 15,
  },
  botMessageContainer: {
    justifyContent: 'flex-start',
  },
  userMessageContainer: {
    justifyContent: 'flex-end',
  },
  botAvatar: {
    width: 35,
    height: 35,
    borderRadius: 17.5,
    backgroundColor: '#4ecdc4',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  messageBubble: {
    maxWidth: '80%',
    paddingHorizontal: 15,
    paddingVertical: 12,
    borderRadius: 20,
  },
  botMessageBubble: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderBottomLeftRadius: 5,
  },
  userMessageBubble: {
    backgroundColor: '#4ecdc4',
    borderBottomRightRadius: 5,
  },
  messageText: {
    fontSize: 16,
    lineHeight: 22,
  },
  botMessageText: {
    color: '#fff',
  },
  userMessageText: {
    color: '#fff',
  },
  messageTime: {
    fontSize: 11,
    marginTop: 5,
  },
  botMessageTime: {
    color: 'rgba(255,255,255,0.6)',
  },
  userMessageTime: {
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'right',
  },
  inputContainer: {
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 25,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  textInput: {
    flex: 1,
    color: '#fff',
    fontSize: 16,
    maxHeight: 100,
    marginRight: 10,
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonActive: {
    backgroundColor: '#4ecdc4',
  },
});