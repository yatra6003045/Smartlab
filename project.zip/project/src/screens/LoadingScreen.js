import React from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import * as Animatable from 'react-native-animatable';
import LinearGradient from 'react-native-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

const { width, height } = Dimensions.get('window');

export default function LoadingScreen() {
  return (
    <LinearGradient
      colors={['#667eea', '#764ba2', '#f093fb']}
      style={styles.container}
    >
      <View style={styles.content}>
        {/* Animated Logo */}
        <Animatable.View
          animation="rotate"
          iterationCount="infinite"
          duration={2000}
          style={styles.logoContainer}
        >
          <View style={styles.logoCircle}>
            <Ionicons name="medical" size={60} color="#fff" />
          </View>
        </Animatable.View>

        {/* Loading Text */}
        <Animatable.Text
          animation="pulse"
          iterationCount="infinite"
          style={styles.loadingText}
        >
          SMARTLAB SILCHAR
        </Animatable.Text>

        {/* Loading Dots */}
        <View style={styles.dotsContainer}>
          <Animatable.View
            animation="bounce"
            iterationCount="infinite"
            delay={0}
            style={[styles.dot, { backgroundColor: '#ff6b6b' }]}
          />
          <Animatable.View
            animation="bounce"
            iterationCount="infinite"
            delay={200}
            style={[styles.dot, { backgroundColor: '#4ecdc4' }]}
          />
          <Animatable.View
            animation="bounce"
            iterationCount="infinite"
            delay={400}
            style={[styles.dot, { backgroundColor: '#45b7d1' }]}
          />
          <Animatable.View
            animation="bounce"
            iterationCount="infinite"
            delay={600}
            style={[styles.dot, { backgroundColor: '#96ceb4' }]}
          />
          <Animatable.View
            animation="bounce"
            iterationCount="infinite"
            delay={800}
            style={[styles.dot, { backgroundColor: '#feca57' }]}
          />
        </View>

        <Text style={styles.subtitle}>Loading your health companion...</Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    alignItems: 'center',
  },
  logoContainer: {
    marginBottom: 30,
  },
  logoCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  loadingText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 30,
    letterSpacing: 2,
  },
  dotsContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  dot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginHorizontal: 4,
  },
  subtitle: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.8)',
    textAlign: 'center',
    fontStyle: 'italic',
  },
});