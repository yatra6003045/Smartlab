import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  SafeAreaView,
} from 'react-native';
import * as Animatable from 'react-native-animatable';
import LinearGradient from 'react-native-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';

const { width } = Dimensions.get('window');

export default function UserDashboard({ navigation }) {
  const { user, logout } = useAuth();

  const dashboardItems = [
    {
      title: 'Book a Test',
      icon: 'calendar',
      color: ['#ff6b6b', '#ee5a52'],
      screen: 'BookTest',
      delay: 100,
    },
    {
      title: 'My Bookings',
      icon: 'list',
      color: ['#4ecdc4', '#44a08d'],
      screen: 'MyBookings',
      delay: 200,
    },
    {
      title: 'Download Report',
      icon: 'download',
      color: ['#45b7d1', '#96c93d'],
      screen: 'Reports',
      delay: 300,
    },
    {
      title: 'Payment Status',
      icon: 'card',
      color: ['#96ceb4', '#feca57'],
      screen: 'Payment',
      delay: 400,
    },
    {
      title: 'AI Assistant',
      icon: 'chatbubble-ellipses',
      color: ['#feca57', '#ff9ff3'],
      screen: 'Chatbot',
      delay: 500,
    },
    {
      title: 'Offers & Discounts',
      icon: 'gift',
      color: ['#ff9ff3', '#f093fb'],
      screen: 'Offers',
      delay: 600,
    },
  ];

  const handleNavigation = (screen) => {
    navigation.navigate(screen);
  };

  return (
    <LinearGradient colors={['#667eea', '#764ba2']} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        {/* Header */}
        <Animatable.View animation="fadeInDown" style={styles.header}>
          <View style={styles.headerLeft}>
            <View style={styles.avatarContainer}>
              <Ionicons name="person" size={24} color="#fff" />
            </View>
            <View>
              <Text style={styles.welcomeText}>Welcome back,</Text>
              <Text style={styles.userName}>{user?.name || 'User'}</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.logoutButton} onPress={logout}>
            <Ionicons name="log-out" size={24} color="#fff" />
          </TouchableOpacity>
        </Animatable.View>

        {/* Dashboard Grid */}
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.gridContainer}>
            {dashboardItems.map((item, index) => (
              <Animatable.View
                key={index}
                animation="fadeInUp"
                delay={item.delay}
                style={styles.gridItemContainer}
              >
                <TouchableOpacity
                  style={styles.gridItem}
                  onPress={() => handleNavigation(item.screen)}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={item.color}
                    style={styles.gridItemGradient}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                  >
                    <View style={styles.iconContainer}>
                      <Ionicons name={item.icon} size={32} color="#fff" />
                    </View>
                    <Text style={styles.gridItemText}>{item.title}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </Animatable.View>
            ))}
          </View>

          {/* Quick Stats */}
          <Animatable.View animation="fadeInUp" delay={700} style={styles.statsContainer}>
            <Text style={styles.statsTitle}>Quick Stats</Text>
            <View style={styles.statsRow}>
              <View style={styles.statItem}>
                <Text style={styles.statNumber}>5</Text>
                <Text style={styles.statLabel}>Total Bookings</Text>
              </View>
              <View style={styles.statItem}>
                <Text style={styles.statNumber}>2</Text>
                <Text style={styles.statLabel}>Pending Reports</Text>
              </View>
              <View style={styles.statItem}>
                <Text style={styles.statNumber}>₹1,200</Text>
                <Text style={styles.statLabel}>Total Spent</Text>
              </View>
            </View>
          </Animatable.View>

          {/* Recent Activity */}
          <Animatable.View animation="fadeInUp" delay={800} style={styles.activityContainer}>
            <Text style={styles.activityTitle}>Recent Activity</Text>
            <View style={styles.activityItem}>
              <View style={styles.activityIcon}>
                <Ionicons name="checkmark-circle" size={20} color="#4ecdc4" />
              </View>
              <View style={styles.activityContent}>
                <Text style={styles.activityText}>Blood Test Completed</Text>
                <Text style={styles.activityTime}>2 hours ago</Text>
              </View>
            </View>
            <View style={styles.activityItem}>
              <View style={styles.activityIcon}>
                <Ionicons name="time" size={20} color="#feca57" />
              </View>
              <View style={styles.activityContent}>
                <Text style={styles.activityText}>Sample Collection Scheduled</Text>
                <Text style={styles.activityTime}>1 day ago</Text>
              </View>
            </View>
          </Animatable.View>
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatarContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  welcomeText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
  },
  userName: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  logoutButton: {
    padding: 10,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 30,
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 30,
  },
  gridItemContainer: {
    width: (width - 60) / 2,
    marginBottom: 20,
  },
  gridItem: {
    height: 120,
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  gridItemGradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 15,
  },
  iconContainer: {
    marginBottom: 10,
  },
  gridItemText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  statsContainer: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
  },
  statsTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  statLabel: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 12,
    marginTop: 5,
  },
  activityContainer: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 20,
    padding: 20,
  },
  activityTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  activityIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  activityContent: {
    flex: 1,
  },
  activityText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  activityTime: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    marginTop: 2,
  },
});