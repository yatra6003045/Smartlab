import React, { useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Image,
} from 'react-native';
import * as Animatable from 'react-native-animatable';
import LinearGradient from 'react-native-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

const { width, height } = Dimensions.get('window');

export default function WelcomeScreen({ navigation }) {
  useEffect(() => {
    // Auto navigate after 5 seconds
    const timer = setTimeout(() => {
      navigation.replace('Login');
    }, 5000);

    return () => clearTimeout(timer);
  }, [navigation]);

  return (
    <LinearGradient
      colors={['#667eea', '#764ba2', '#f093fb']}
      style={styles.container}
    >
      <View style={styles.content}>
        {/* Logo Animation */}
        <Animatable.View
          animation="bounceIn"
          duration={2000}
          style={styles.logoContainer}
        >
          <View style={styles.logoCircle}>
            <Ionicons name="medical" size={80} color="#fff" />
          </View>
        </Animatable.View>

        {/* Title Animation */}
        <Animatable.View
          animation="fadeInUp"
          delay={1000}
          duration={1500}
          style={styles.titleContainer}
        >
          <Text style={styles.title}>SMARTLAB</Text>
          <Text style={styles.subtitle}>SILCHAR</Text>
          <Text style={styles.tagline}>AI-Powered Diagnostic Lab Platform</Text>
        </Animatable.View>

        {/* Features Animation */}
        <Animatable.View
          animation="fadeInUp"
          delay={2000}
          duration={1500}
          style={styles.featuresContainer}
        >
          <View style={styles.feature}>
            <Ionicons name="flash" size={24} color="#fff" />
            <Text style={styles.featureText}>Quick Booking</Text>
          </View>
          <View style={styles.feature}>
            <Ionicons name="shield-checkmark" size={24} color="#fff" />
            <Text style={styles.featureText}>Secure Reports</Text>
          </View>
          <View style={styles.feature}>
            <Ionicons name="chatbubble-ellipses" size={24} color="#fff" />
            <Text style={styles.featureText}>AI Assistant</Text>
          </View>
        </Animatable.View>

        {/* Get Started Button */}
        <Animatable.View
          animation="pulse"
          iterationCount="infinite"
          delay={3000}
          style={styles.buttonContainer}
        >
          <TouchableOpacity
            style={styles.getStartedButton}
            onPress={() => navigation.replace('Login')}
          >
            <Text style={styles.buttonText}>Get Started</Text>
            <Ionicons name="arrow-forward" size={24} color="#667eea" />
          </TouchableOpacity>
        </Animatable.View>
      </View>

      {/* Bottom Wave */}
      <Animatable.View
        animation="slideInUp"
        delay={1500}
        style={styles.waveContainer}
      >
        <View style={styles.wave} />
      </Animatable.View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 30,
  },
  logoContainer: {
    marginBottom: 40,
  },
  logoCircle: {
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  titleContainer: {
    alignItems: 'center',
    marginBottom: 40,
  },
  title: {
    fontSize: 42,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    letterSpacing: 2,
  },
  subtitle: {
    fontSize: 28,
    fontWeight: '600',
    color: '#fff',
    textAlign: 'center',
    marginTop: -5,
    letterSpacing: 1,
  },
  tagline: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.8)',
    textAlign: 'center',
    marginTop: 10,
    fontStyle: 'italic',
  },
  featuresContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginBottom: 50,
  },
  feature: {
    alignItems: 'center',
    flex: 1,
  },
  featureText: {
    color: '#fff',
    fontSize: 12,
    marginTop: 8,
    textAlign: 'center',
  },
  buttonContainer: {
    marginTop: 20,
  },
  getStartedButton: {
    backgroundColor: '#fff',
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 30,
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  buttonText: {
    color: '#667eea',
    fontSize: 18,
    fontWeight: 'bold',
    marginRight: 10,
  },
  waveContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 100,
  },
  wave: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderTopLeftRadius: 50,
    borderTopRightRadius: 50,
  },
});