import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  SafeAreaView,
} from 'react-native';
import * as Animatable from 'react-native-animatable';
import LinearGradient from 'react-native-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useData } from '../context/DataContext';

export default function BookTestScreen({ navigation }) {
  const { tests, labs, bookTest } = useData();
  const [selectedLab, setSelectedLab] = useState('Lal PathLabs');
  const [selectedTests, setSelectedTests] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isUrgent, setIsUrgent] = useState(false);

  const filteredTests = tests.filter(test =>
    test.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const calculatePrice = (test) => {
    const discount = labs[selectedLab] || 0;
    return Math.round(test.price * (1 - discount / 100));
  };

  const getTotalAmount = () => {
    return selectedTests.reduce((total, testId) => {
      const test = tests.find(t => t.id === testId);
      return total + (test ? calculatePrice(test) : 0);
    }, 0);
  };

  const toggleTestSelection = (testId) => {
    setSelectedTests(prev =>
      prev.includes(testId)
        ? prev.filter(id => id !== testId)
        : [...prev, testId]
    );
  };

  const handleBookTest = () => {
    if (selectedTests.length === 0) {
      Alert.alert('Error', 'Please select at least one test');
      return;
    }

    const booking = {
      tests: selectedTests.map(id => tests.find(t => t.id === id)),
      lab: selectedLab,
      totalAmount: getTotalAmount(),
      isUrgent,
      status: 'confirmed',
      createdAt: new Date().toISOString(),
    };

    bookTest(booking);
    Alert.alert('Success', 'Test booked successfully!', [
      { text: 'OK', onPress: () => navigation.goBack() }
    ]);
  };

  return (
    <LinearGradient colors={['#667eea', '#764ba2']} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        {/* Header */}
        <Animatable.View animation="fadeInDown" style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <Ionicons name="arrow-back" size={24} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Book a Test</Text>
          <View style={styles.placeholder} />
        </Animatable.View>

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {/* Lab Selection */}
          <Animatable.View animation="fadeInUp" delay={200} style={styles.section}>
            <Text style={styles.sectionTitle}>Select Lab</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={styles.labContainer}>
                {Object.keys(labs).map((lab) => (
                  <TouchableOpacity
                    key={lab}
                    style={[
                      styles.labButton,
                      selectedLab === lab && styles.selectedLabButton
                    ]}
                    onPress={() => setSelectedLab(lab)}
                  >
                    <Text style={[
                      styles.labButtonText,
                      selectedLab === lab && styles.selectedLabButtonText
                    ]}>
                      {lab}
                    </Text>
                    <Text style={[
                      styles.discountText,
                      selectedLab === lab && styles.selectedDiscountText
                    ]}>
                      {labs[lab]}% OFF
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
          </Animatable.View>

          {/* Search */}
          <Animatable.View animation="fadeInUp" delay={400} style={styles.section}>
            <View style={styles.searchContainer}>
              <Ionicons name="search" size={20} color="rgba(255,255,255,0.7)" />
              <TextInput
                style={styles.searchInput}
                placeholder="Search tests..."
                placeholderTextColor="rgba(255,255,255,0.7)"
                value={searchQuery}
                onChangeText={setSearchQuery}
              />
            </View>
          </Animatable.View>

          {/* Urgent Booking Toggle */}
          <Animatable.View animation="fadeInUp" delay={500} style={styles.section}>
            <TouchableOpacity
              style={styles.urgentToggle}
              onPress={() => setIsUrgent(!isUrgent)}
            >
              <View style={styles.urgentToggleLeft}>
                <Ionicons name="flash" size={20} color="#ff6b6b" />
                <Text style={styles.urgentToggleText}>Urgent Booking</Text>
              </View>
              <View style={[
                styles.toggleSwitch,
                isUrgent && styles.toggleSwitchActive
              ]}>
                <View style={[
                  styles.toggleKnob,
                  isUrgent && styles.toggleKnobActive
                ]} />
              </View>
            </TouchableOpacity>
          </Animatable.View>

          {/* Test List */}
          <Animatable.View animation="fadeInUp" delay={600} style={styles.section}>
            <Text style={styles.sectionTitle}>Available Tests</Text>
            {filteredTests.map((test, index) => {
              const isSelected = selectedTests.includes(test.id);
              const discountedPrice = calculatePrice(test);
              
              return (
                <Animatable.View
                  key={test.id}
                  animation="fadeInUp"
                  delay={700 + index * 50}
                  style={styles.testItem}
                >
                  <TouchableOpacity
                    style={[
                      styles.testButton,
                      isSelected && styles.selectedTestButton
                    ]}
                    onPress={() => toggleTestSelection(test.id)}
                  >
                    <View style={styles.testInfo}>
                      <Text style={[
                        styles.testName,
                        isSelected && styles.selectedTestName
                      ]}>
                        {test.name}
                      </Text>
                      <View style={styles.priceContainer}>
                        <Text style={[
                          styles.originalPrice,
                          isSelected && styles.selectedOriginalPrice
                        ]}>
                          ₹{test.price}
                        </Text>
                        <Text style={[
                          styles.discountedPrice,
                          isSelected && styles.selectedDiscountedPrice
                        ]}>
                          ₹{discountedPrice}
                        </Text>
                      </View>
                    </View>
                    <View style={[
                      styles.checkbox,
                      isSelected && styles.selectedCheckbox
                    ]}>
                      {isSelected && (
                        <Ionicons name="checkmark" size={16} color="#fff" />
                      )}
                    </View>
                  </TouchableOpacity>
                </Animatable.View>
              );
            })}
          </Animatable.View>
        </ScrollView>

        {/* Bottom Bar */}
        {selectedTests.length > 0 && (
          <Animatable.View animation="slideInUp" style={styles.bottomBar}>
            <View style={styles.totalContainer}>
              <Text style={styles.totalLabel}>Total Amount</Text>
              <Text style={styles.totalAmount}>₹{getTotalAmount()}</Text>
            </View>
            <TouchableOpacity style={styles.bookButton} onPress={handleBookTest}>
              <Text style={styles.bookButtonText}>Book Now</Text>
              <Ionicons name="arrow-forward" size={20} color="#fff" />
            </TouchableOpacity>
          </Animatable.View>
        )}
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  backButton: {
    padding: 5,
  },
  headerTitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 34,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  section: {
    marginBottom: 25,
  },
  sectionTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  labContainer: {
    flexDirection: 'row',
    paddingRight: 20,
  },
  labButton: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderRadius: 15,
    marginRight: 15,
    alignItems: 'center',
    minWidth: 100,
  },
  selectedLabButton: {
    backgroundColor: '#fff',
  },
  labButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  selectedLabButtonText: {
    color: '#667eea',
  },
  discountText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 12,
    marginTop: 2,
  },
  selectedDiscountText: {
    color: '#667eea',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 15,
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  searchInput: {
    flex: 1,
    marginLeft: 10,
    color: '#fff',
    fontSize: 16,
  },
  urgentToggle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 15,
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  urgentToggleLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  urgentToggleText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 10,
  },
  toggleSwitch: {
    width: 50,
    height: 25,
    borderRadius: 12.5,
    backgroundColor: 'rgba(255,255,255,0.3)',
    justifyContent: 'center',
    paddingHorizontal: 2,
  },
  toggleSwitchActive: {
    backgroundColor: '#4ecdc4',
  },
  toggleKnob: {
    width: 21,
    height: 21,
    borderRadius: 10.5,
    backgroundColor: '#fff',
  },
  toggleKnobActive: {
    alignSelf: 'flex-end',
  },
  testItem: {
    marginBottom: 15,
  },
  testButton: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 15,
    padding: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  selectedTestButton: {
    backgroundColor: '#fff',
  },
  testInfo: {
    flex: 1,
  },
  testName: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 5,
  },
  selectedTestName: {
    color: '#667eea',
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  originalPrice: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 14,
    textDecorationLine: 'line-through',
    marginRight: 10,
  },
  selectedOriginalPrice: {
    color: 'rgba(102, 126, 234, 0.6)',
  },
  discountedPrice: {
    color: '#4ecdc4',
    fontSize: 16,
    fontWeight: 'bold',
  },
  selectedDiscountedPrice: {
    color: '#667eea',
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedCheckbox: {
    backgroundColor: '#4ecdc4',
    borderColor: '#4ecdc4',
  },
  bottomBar: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 20,
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
  },
  totalContainer: {
    flex: 1,
  },
  totalLabel: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
  },
  totalAmount: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  bookButton: {
    backgroundColor: '#4ecdc4',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 25,
    flexDirection: 'row',
    alignItems: 'center',
  },
  bookButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    marginRight: 10,
  },
});