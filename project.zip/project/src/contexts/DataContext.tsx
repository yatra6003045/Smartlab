import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';

export interface Test {
  id: string;
  name: string;
  mrp: number;
  discounts: {
    'Lal Path': number;
    'Lupin': number;
    'Biomed': number;
    'Metropolis': number;
  };
}

export interface Booking {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  tests: string[];
  lab: string;
  totalAmount: number;
  paidAmount: number;
  status: 'confirmed' | 'assigned' | 'collected' | 'in_lab' | 'report_ready';
  assignedPhlebo?: string;
  createdAt: string;
  prescription?: string;
  reportUrl?: string;
  isUrgent?: boolean;
}

export interface Phlebotomist {
  id: string;
  name: string;
  password: string;
  isBlocked: boolean;
  totalCommission: number;
  cashCollected: number;
}

interface DataContextType {
  tests: Test[];
  bookings: Booking[];
  phlebotomists: Phlebotomist[];
  qrCode: string;
  addBooking: (booking: Omit<Booking, 'id' | 'createdAt'>) => void;
  updateBooking: (id: string, updates: Partial<Booking>) => void;
  addPhlebotomist: (phlebo: Omit<Phlebotomist, 'totalCommission' | 'cashCollected'>) => void;
  updatePhlebotomist: (id: string, updates: Partial<Phlebotomist>) => void;
  updateQrCode: (qr: string) => void;
  addTest: (test: Omit<Test, 'id'>) => void;
  updateTest: (id: string, updates: Partial<Test>) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

// Generate dummy test data
const generateTests = (): Test[] => {
  const testNames = [
    'Complete Blood Count (CBC)', 'Blood Sugar Fasting', 'Blood Sugar Random', 'HbA1c', 'Lipid Profile',
    'Liver Function Test', 'Kidney Function Test', 'Thyroid Profile', 'Vitamin D', 'Vitamin B12',
    'Iron Studies', 'Urine Routine', 'ECG', 'Chest X-Ray', 'Ultrasound Abdomen',
    'CT Scan Head', 'MRI Brain', 'Mammography', 'Pap Smear', 'PSA',
    'Testosterone', 'Estrogen', 'Prolactin', 'LH', 'FSH',
    'Cortisol', 'ACTH', 'Growth Hormone', 'Insulin', 'C-Peptide',
    'Troponin I', 'CK-MB', 'D-Dimer', 'PT/INR', 'APTT',
    'Fibrinogen', 'ESR', 'CRP', 'Procalcitonin', 'Ferritin',
    'TIBC', 'Transferrin', 'Folate', 'Homocysteine', 'Uric Acid',
    'Calcium', 'Phosphorus', 'Magnesium', 'Zinc', 'Copper',
    'HIV', 'HBsAg', 'HCV', 'VDRL', 'Dengue NS1',
    'Malaria Antigen', 'Typhoid', 'Widal Test', 'Tuberculosis', 'COVID-19 RT-PCR'
  ];

  return testNames.map((name, index) => ({
    id: `test_${index + 1}`,
    name,
    mrp: Math.floor(Math.random() * 5000) + 200,
    discounts: {
      'Lal Path': 10,
      'Lupin': 15,
      'Biomed': 15,
      'Metropolis': 25,
    },
  }));
};

export function DataProvider({ children }: { children: ReactNode }) {
  const [tests, setTests] = useState<Test[]>(() => {
    const stored = localStorage.getItem('smartlab_tests');
    return stored ? JSON.parse(stored) : generateTests();
  });

  const [bookings, setBookings] = useState<Booking[]>(() => {
    const stored = localStorage.getItem('smartlab_bookings');
    return stored ? JSON.parse(stored) : [];
  });

  const [phlebotomists, setPhlebotomists] = useState<Phlebotomist[]>(() => {
    const stored = localStorage.getItem('smartlab_phlebos');
    return stored ? JSON.parse(stored) : [
      {
        id: '6003045851',
        name: 'Initial Phlebo',
        password: '10122003',
        isBlocked: false,
        totalCommission: 0,
        cashCollected: 0,
      }
    ];
  });

  const [qrCode, setQrCode] = useState(() => {
    return localStorage.getItem('smartlab_qr') || 'https://via.placeholder.com/200x200?text=QR+Code';
  });

  useEffect(() => {
    localStorage.setItem('smartlab_tests', JSON.stringify(tests));
  }, [tests]);

  useEffect(() => {
    localStorage.setItem('smartlab_bookings', JSON.stringify(bookings));
  }, [bookings]);

  useEffect(() => {
    localStorage.setItem('smartlab_phlebos', JSON.stringify(phlebotomists));
  }, [phlebotomists]);

  useEffect(() => {
    localStorage.setItem('smartlab_qr', qrCode);
  }, [qrCode]);

  const addBooking = (booking: Omit<Booking, 'id' | 'createdAt'>) => {
    const newBooking: Booking = {
      ...booking,
      id: `booking_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setBookings(prev => [...prev, newBooking]);
  };

  const updateBooking = (id: string, updates: Partial<Booking>) => {
    setBookings(prev => prev.map(booking => 
      booking.id === id ? { ...booking, ...updates } : booking
    ));
  };

  const addPhlebotomist = (phlebo: Omit<Phlebotomist, 'totalCommission' | 'cashCollected'>) => {
    const newPhlebo: Phlebotomist = {
      ...phlebo,
      totalCommission: 0,
      cashCollected: 0,
    };
    setPhlebotomists(prev => [...prev, newPhlebo]);
  };

  const updatePhlebotomist = (id: string, updates: Partial<Phlebotomist>) => {
    setPhlebotomists(prev => prev.map(phlebo => 
      phlebo.id === id ? { ...phlebo, ...updates } : phlebo
    ));
  };

  const updateQrCode = (qr: string) => {
    setQrCode(qr);
  };

  const addTest = (test: Omit<Test, 'id'>) => {
    const newTest: Test = {
      ...test,
      id: `test_${Date.now()}`,
    };
    setTests(prev => [...prev, newTest]);
  };

  const updateTest = (id: string, updates: Partial<Test>) => {
    setTests(prev => prev.map(test => 
      test.id === id ? { ...test, ...updates } : test
    ));
  };

  return (
    <DataContext.Provider value={{
      tests,
      bookings,
      phlebotomists,
      qrCode,
      addBooking,
      updateBooking,
      addPhlebotomist,
      updatePhlebotomist,
      updateQrCode,
      addTest,
      updateTest,
    }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}